# GAMES202 homework0

## Usage

### For Visual Studio Code
Install plugin `Live Sever` and run with `index.html` directly

### For Node.js users
To install:
```
npm install http-server -g
```
To run(from `index.html` directory):
```
http-server . -p 8000
```

## In-web operation
- Hold right mouse to rotate the camera
- Scroll mouse wheel to zoom in/out
- Hold left mouse to move the camera
- Hold left mouse only to drag the GUI